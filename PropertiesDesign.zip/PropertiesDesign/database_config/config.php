<?php
    $dbURL ="localhost";
    $userName = "root";
    $password = "";
    $database = "nova_associates";
    
    //database connection
    $conn = mysqli_connect($dbURL, $userName, $password, $database) or die("Unable to connect to database");
?>