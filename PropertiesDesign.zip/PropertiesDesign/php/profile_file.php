<?php
session_start();
include '../database_config/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $location = "../profile_images/download.png"; // Fallback image if no upload
    
    // Handle image upload if provided
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $imageName = basename($_FILES['image']['name']);
        $targetDir = "../profile_images/";
        $uniqueName = uniqid() . "_" . $imageName;
        $targetFile = $targetDir . $uniqueName;

        // Move uploaded file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $location = $targetFile;
        }
    }

    $oldEmail = $_SESSION['email'];
    
    // Prepare and execute update
    $updateSQL = "UPDATE `person` 
        SET `firstname` = ?, 
            `lastname` = ?, 
            `email` = ?, 
            `phone` = ?, 
            `password` = ?, 
            `location` = ? 
        WHERE `email` = ?";

    $stmt = $conn->prepare($updateSQL);

    $stmt->bind_param("sssssss", $firstName, $lastName, $email, $phone, $password, $location, $oldEmail);

    if ($stmt->execute()) {
        // Update session email if changed
        $_SESSION['email'] = $email;
        
        $_SESSION['location'] = $location;
        $_SESSION['username'] = $firstName;
        
        $mail = new PHPMailer(true);

        try {
            // Set mailer to use SMTP
            $mail->isSMTP();

            // Specify main and backup SMTP servers
            $mail->Host = 'smtp.gmail.com';

            // Enable SMTP authentication
            $mail->SMTPAuth = true;

            // SMTP username
            $mail->Username = 'bryannevhutalu7@gmail.com';

            // SMTP password
            $mail->Password = 'giczlilkdytwrkuc';

            // Enable TLS encryption, `ssl` also accepted
            $mail->SMTPSecure = 'ssl';

            // TCP port to connect to
            $mail->Port = 465;

            //Recipients
            $mail->setFrom('bryannevhutalu7@gmail.com', 'Nova Associate Account');

            // Add a recipient
            $mail->addAddress($email);

            // Optional: Add reply-to address
            $mail->addReplyTo($email, 'Information');

            // Content
            $mail->isHTML(true);
            // Set email format to HTML
            $mail->Subject = 'Nova Associate Account Update';
            $mail->Body = "Hi <b>".$firstName." "."$lastName</b><br><br>"
                    . "We wanted to let you know that your profile information was successfully updated.<br><br>"
                    . "If you made these changes, no further action is needed. If you did not make these changes,<br> please contact our support team immediately for assistance.<br><br>"
                    . "Thanks<br>"
                    . "The <b>Nova Associate</b> Team ";
            $mail->AltBody = '';

            $mail->send();
            echo "<script>alert('✅ Customer updated successfully.'); window.location.href='../php/profile.php';</script>";
        exit();
        } catch (Exception $e) {
            echo "<script>alert('❌ Email is not sent. Mailer Error: {$mail->ErrorInfo} ');</script>";
            exit();
        }
        
    } else {
        echo "<script>alert('❌ Update failed: " . $stmt->error . "'); window.location.href='../php/profile.php';</script>";
        exit();
    }

    $stmt->close();
}
?>
