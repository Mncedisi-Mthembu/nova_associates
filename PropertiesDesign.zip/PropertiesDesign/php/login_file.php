<?php

session_start();
include '../database_config/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    //checking email from database
    $searchSQL = "SELECT * FROM person " .
            "WHERE email = '$email' " .
            "AND " .
            "Password = '$password' ";

    $userLoginResult = $conn->query($searchSQL);

    //checking the result number of rows
    if ($userLoginResult->num_rows == 1) {
        // Fetch the row as an associative array
        $row = $userLoginResult->fetch_assoc();

        //Store the values to the session
        $_SESSION['active'] = 0;
        $_SESSION['email'] = $email;
        $_SESSION['location'] = $row['location'];
        $_SESSION['username'] = $row['firstname'];

        echo "<script>alert('✅ Successfully login');window.location.href = '../php/properties.php';</script>";
        exit();
    } else {
        echo "<script>alert('❌ Invalid login details');window.location.href = '../php/login.php';</script>";
        exit();
    }
}

