<footer class="bg-dark py-5 mt-5">
    <div class="container text-light text-center">
        <p></p>
        <small class="text-white-50">Copyright &copy;<?php echo date("Y"); ?> Nova Associates. All rights reserved</small>
    </div>
</footer>

<script src="../javascript/submit_payment_form.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<!-- Include Bootstrap JS (jQuery and Popper required for Bootstrap 4) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>