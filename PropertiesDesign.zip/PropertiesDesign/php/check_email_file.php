<?php

session_start();
include '../database_config/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    //checking email from database
    $searchSQL = "SELECT * FROM person " .
            "WHERE email = '$email' ";

    $userLoginResult = $conn->query($searchSQL);

    //checking the result number of rows
    if ($userLoginResult->num_rows == 1) {
        $randomNumber = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $_SESSION['email'] = $email;
        $_SESSION['randomNumber'] = $randomNumber;

        $mail = new PHPMailer(true);

        try {
            // Set mailer to use SMTP
            $mail->isSMTP();

            // Specify main and backup SMTP servers
            $mail->Host = 'smtp.gmail.com';

            // Enable SMTP authentication
            $mail->SMTPAuth = true;

            // SMTP username
            $mail->Username = 'bryannevhutalu7@gmail.com';

            // SMTP password
            $mail->Password = 'giczlilkdytwrkuc';

            // Enable TLS encryption, `ssl` also accepted
            $mail->SMTPSecure = 'ssl';

            // TCP port to connect to
            $mail->Port = 465;

            //Recipients
            $mail->setFrom('bryannevhutalu7@gmail.com', 'Reset Password');

            // Add a recipient
            $mail->addAddress($email);

            // Optional: Add reply-to address
            $mail->addReplyTo($email, 'Information');

            // Content
            $mail->isHTML(true);
            // Set email format to HTML
            $mail->Subject = 'Reset Password';
            $mail->Body = "Below is the password code for updating password<br><br>"
                    . "<b>Your OTP Code for password reset is:$randomNumber</b>";
            $mail->AltBody = '';

            $mail->send();
            echo "<script>alert('✅ Email have been sent with OTP verification code');</script>";
            echo "<script>window.location.href = '../php/reset_password_OTP.php';</script>";
            exit();
        } catch (Exception $e) {
            echo "<script>alert('❌ Email is not sent. Mailer Error: {$mail->ErrorInfo} ');</script>";
            exit();
        }
    } else {
        echo "<script>alert('❌ Invalid email address');window.location.href = '../php/reset_password.php';</script>";
        exit();
    }
}

