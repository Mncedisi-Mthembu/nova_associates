<?php
session_start();
session_unset();    // Clear session variables
session_destroy();  // Destroy session
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Signed Out</title>
        <style>
            body {
                background-image: linear-gradient(rgba(0,0,0,0.100),rgba(0,0,0,0.100)),url(https://plus.unsplash.com/premium_photo-1661908377130-772731de98f6?q=80&w=1412&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D);
                background-size: cover;
                font-family: Arial, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .message-box {
                background: #fff;
                padding: 30px 40px;
                border-radius: 10px;
                box-shadow: 0 4px 10px rgba(0,0,0,0.1);
                text-align: center;
            }
            .message-box h2 {
                color: #28a745;
                margin-bottom: 15px;
            }
            .message-box a {
                text-decoration: none;
                color: #007bff;
                font-weight: bold;
            }
        </style>
        <meta http-equiv="refresh" content="5;url=../index.html">
    </head>
    <body>
        <div class="message-box">
            <h2>Signed Out Successfully</h2>
            <p>You have been logged out.</p>
            <p>Redirecting to <a href="../index.html">Login Page</a> in <span id="count">5</span> seconds...</p>
        </div>
    </body>
      <script>
        let seconds = 5; // Initial countdown time
        const countdown = setInterval(() => {
            document.getElementById('count').textContent = seconds;
            if (seconds === 0) {
                clearInterval(countdown);
                window.location.href = '../index.html';
            }
            seconds--;
        }, 1000);
    </script>
</html>
