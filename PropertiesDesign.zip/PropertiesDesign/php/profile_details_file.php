<?php
session_start();
include '../database_config/config.php';

$email = $_SESSION["email"]; // Replace with the actual email

$stmt = $conn->prepare("SELECT * FROM `person` WHERE `email` = ?");
$stmt->bind_param("s", $email); // "s" means string
$stmt->execute();

$result = $stmt->get_result();

$location = '';$firstName = '';$lastName ='';
$email = ''; $phone = '';

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    //Retrieve data from the database
    $location = $row['location'];
    $firstName = $row['firstname'];
    $lastName = $row['lastname'];
    $email = $row['email'];
    $phone = $row['phone'];
    
}
