<!-- Modal -->
<div class="modal fade" id="addnew" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title w-100 text-center" id="modalLabel">Profile</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Scrollable Form -->
            <div class="modal-body">
                <form id="profileForm" action="../php/profile_file.php" method="Post" enctype="multipart/form-data" onsubmit=" return isValidateProfile()">
                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name:</label>
                        <input type="text" class="form-control" id="firstName" name="firstName" >
                        <span id="firstName-error" class="error-message" ></span><!-- Error message inside the field -->
                    </div>

                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name:</label>
                        <input type="text" class="form-control" id="lastName" name="lastName" >
                        <span id="lastName-error" class="error-message" ></span><!-- Error message inside the field -->
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address:</label>
                        <input type="email" class="form-control" id="email" name="email" >
                        <span id="email-error" class="error-message" ></span><!-- Error message inside the field -->
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" >
                        <span id="password-error" class="error-message"></span><!-- Error message inside the field -->
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Contact No:</label>
                        <input type="text" class="form-control" id="phone" name="phone" >
                        <span id="phone-error" class="error-message" ></span><!-- Error message inside the field -->
                    </div>
                    
                    <div class="mb-3">
                        <label for="image" class="form-label">Upload Image:</label>
                        <input type="file" class="form-control" name="image" id="image" accept="image/*">
                        <span id="image-error" class="error-message" ></span><!-- Error message inside the field -->
                    </div>

                    <!-- Fixed Footer -->
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>