<?php

session_start();
include '../database_config/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_SESSION['email'];
    $new_password = $_POST['password'];

    //checking email from database
    $updateSQL = "UPDATE person " .
            "SET password = '$new_password' " .
            "WHERE email = '$email' ";

    if ($conn->query($updateSQL) === TRUE) {
        echo "<script>alert('✅ Password has been successfully updated');</script>";
        echo "<script>window.location.href = '../php/login.php';</script>";
        exit();
    } else {
        echo "<script>alert('❌ Something went wrong with your new password and email');</script>";
        echo "<script>window.location.href = '../php/reset_password.php';</script>";
        exit();
    }
}

