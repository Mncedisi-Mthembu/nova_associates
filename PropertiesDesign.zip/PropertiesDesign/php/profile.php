<!DOCTYPE html>
<html lang="en">
    <head>
        <style>
            body{
                background-image: linear-gradient(rgba(0,0,0,0.100),rgba(0,0,0,0.100)),url(https://plus.unsplash.com/premium_photo-1661908377130-772731de98f6?q=80&w=1412&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D);
                background-size: cover;
                font-family: 'Poppins', sans-serif;
            }
        </style>
        <meta charset="UTF-8">
        <title>User Profile</title>
        <!-- Bootstrap 5 CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../css/error_message.css">
    </head>
    <body>
        <div class="d-flex justify-content-center align-items-center vh-100">
            <div class="profile-card card text-center shadow-sm p-3" style="width: 350px;">
                <div class="card-body">
                    
                    <?php include '../php/profile_details_file.php';?>
                    
                    <div class="profile-image-container mb-3">
                        <img src="<?php echo $location; ?>" alt="Profile Image" class="rounded-circle" width="100">
                    </div>
                    <h2 class="card-title"><?php echo $firstName . ' ' . $lastName; ?></h2>
                    <p><strong>Email Address:</strong> <?php echo $email; ?></p>
                    <p><strong>Contact No:</strong> <?php echo $phone; ?></p>

                    <div class="d-flex justify-content-center gap-3 mt-3">
                        <button class="btn btn-danger" onclick="window.location.href = '../php/properties.php'">Close</button>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addnew">Update</button>
                    </div>
                </div>
            </div>
        </div>
        <?php include '../php/modal_profile.php'; ?>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="../javascript/profile.js"></script>
    </body>
</html>
