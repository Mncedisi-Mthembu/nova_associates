<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="image/x-icon" href="../images/logo.jpg">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/error_message.css">
    <title>Reset Password</title>
</head>
<body>
    <div class="container">
        <div class="form">
            <span class="title">Reset Password</span></br>
            <form  id="resetPasswordForm" action="../php/reset_password_file.php" method="post" onsubmit="return isCheckPassword()">
                <p class="text">
                    Enter and verify your new password
                </p>
                <div class="field">
                    <input type="password" name="password" id="password" placeholder="New Password" />
                    <i class='bx bxs-lock-alt icon'></i>
                </div>
                <span id="password-error" class="error-message"></span>

                <div class="field">
                    <input type="password" name="confirm_password" id="confirm_password"  placeholder="Confirm Password" />
                    <i class='bx bxs-lock-alt icon'></i>
                </div>
                <span id="confirm_password-error" class="error-message"></span>

                <div class="field button">
                    <input type="submit" value="Reset Password">
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
     integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
     crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="../javascript/compare_reset_passwords.js"></script>
</body>
</html>