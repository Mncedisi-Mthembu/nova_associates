<!DOCTYPE html>
<html lang="en">
    <head>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <link rel="icon" type="image/x-icon" href="../images/logo.jpg">
        <link rel="stylesheet" href="../css/reset.css"> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>OTP Verification</title>
        <link rel="stylesheet" href="../css/otp_code.css">
        <link rel="stylesheet" href="../css/error_message.css">
    </head>
    <body>
        <?php
        session_start();
        $randomNumber = $_SESSION['randomNumber'];
        ?>
        <div class="otp-container">
            <h2>OTP Verification</h2>
            <p>Enter the 6-digit OTP sent to your email/phone:</p>
            <form id="otpForm" method="Post" action="../php/reset_password_page.php">
                <div class="otp-box">
                    <input type="text" maxlength="1" class="otp-input" required>
                    <input type="text" maxlength="1" class="otp-input" required>
                    <input type="text" maxlength="1" class="otp-input" required>
                    <input type="text" maxlength="1" class="otp-input" required>
                    <input type="text" maxlength="1" class="otp-input" required>
                    <input type="text" maxlength="1" class="otp-input" required>
                    <input type="hidden" name="randomNumber" id="randomNumber" value="<?php echo $randomNumber; ?>"> 
                </div>
                <button type="submit">Verify OTP</button>
                <p class="message" id="errorMessage"></p>
            </form>
        </div>
        <script src="../javascript/otp_code_verification.js"></script>
    </body>
</html>