<?php

session_start();
include '../database_config/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullnames = $_POST['fullnames'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $suburb = $_POST['suburb'];
    $postCode = $_POST['postCode'];

    //Retrieve bank data from form
    $bankName = $_POST['card'];
    $cardNumber = $_POST['cardNumber'];
    $amount = $_POST['amount'];
    $expiry = $_POST['expiry'];
    $cvv = $_POST['cvv'];

    //Retrieve orders data from session
    $image_id = $_SESSION['image_id'];
    $name = $_SESSION['name'];
    $price = $_SESSION['price'];
    $document = $_SESSION['document'];
    $currentDate = date('Y-m-d');

    //Retrieve email from session
    $personEmail = $_SESSION['email'];
    
    //Calculate change
    $change = $amount - $price;

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO `customer`(`person_email`, `fullname`, `email`, `address`, `city`, `suburb`, `postalcode`) VALUES (?, ?, ?, ?, ?, ?, ?)");

    // Bind parameters (all strings here, so use "sssssss")
    $stmt->bind_param("ssssssi", $personEmail, $fullnames, $email, $address, $city, $suburb, $postCode);

    $isExecutedCustomer = FALSE;
    $isExecutedBank = FALSE;
    $isExecutedOrders = FALSE;

    // Execute and check result
    if ($stmt->execute()) {
        $isExecutedCustomer = TRUE;
    }

    if ($isExecutedCustomer) {
        // Prepare SQL statement
        $stmtt = $conn->prepare("INSERT INTO `bank`(`person_email`, `customer_email`, `bank_name`, `credit_card`, `expiry_date`, `cvv`, `amount`) VALUES (?, ?, ?, ?, ?, ?, ?)");

        // Bind parameters
        $stmtt->bind_param("ssssssd", $personEmail, $email, $bankName, $cardNumber, $expiry, $cvv, $amount);

        // Execute and check for success
        if ($stmtt->execute()) {
            $isExecutedBank = TRUE;
        }


        // Prepare SQL statement
        $stmttt = $conn->prepare("INSERT INTO `orders`(`person_email`, `customer_email`, `image_name`, `image_price`, `image_id`, `design_location`) VALUES (?, ?, ?, ?, ?, ?)");

        // Bind parameters (d = double for image_price)
        $stmttt->bind_param("sssdis", $personEmail, $email, $name, $price, $image_id, $document);

        // Execute and check
        if ($stmttt->execute()) {
            $isExecutedOrders = TRUE;
        }
    }

    if ($isExecutedCustomer && $isExecutedBank && $isExecutedOrders) {
        $mail = new PHPMailer(true);

        try {
            //Server settings
            // Set mailer to use SMTP
            $mail->isSMTP();

            // Specify main and backup SMTP servers
            $mail->Host = 'smtp.gmail.com';

            // Enable SMTP authentication
            $mail->SMTPAuth = true;

            // SMTP username
            $mail->Username = 'bryannevhutalu7@gmail.com';

            // SMTP password
            $mail->Password = 'giczlilkdytwrkuc';

            // Enable TLS encryption, `ssl` also accepted
            $mail->SMTPSecure = 'ssl';

            // TCP port to connect to
            $mail->Port = 465;

            //Recipients
            $mail->setFrom('bryannevhutalu7@gmail.com', 'Nova associate');

            // Add a recipient
            $mail->addAddress($email);

            // Optional: Add reply-to address
            $mail->addReplyTo($email, 'Information');

            $mail->addAttachment($document);
            // Content
            $mail->isHTML(true);

            // Set email format to HTML
            $mail->Subject = 'Payment';
            $mail->Body = "Dear $fullnames<br><br>"
                    . "I hope this email finds you well.<br><br>"
                    ."<b>$fullnames</b> your payments is recieved <br><b>Below is the house plan details you buy :</b><br>"
                    . "<ul>"
                    . "<li>$name</li>"
                    . "<li>Cost R$price</li>"
                    . "<li>Change R$change</li>"
                    . "</ul>"
                    . "Below is the pdf that tell you more about <b>Nova Associate</b><br><br>"
                    . "<b>Thank you</b>";
            $mail->AltBody = '';

            $mail->send();
            echo "<script>alert('✅ Confrimation payment has been sent to your email');window.location.href='../php/properties.php';</script>";
            exit();
        } catch (Exception $e) {
            echo "<script>alert('❌ Message could not be sent. Mailer Error: {$mail->ErrorInfo} ');window.location.href='../php/proceed_payment.php';</script>";
            exit();
        }
    } 
    else {
        echo "<script>alert('❌ Something went wrong with storing your data.');window.location.href='../php/proceed_payment.php';</script>";
        exit();
    }
}

