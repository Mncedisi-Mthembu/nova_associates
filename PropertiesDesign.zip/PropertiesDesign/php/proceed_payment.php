<?php
session_start();
$price = $_SESSION['price'];
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Proceed Payment Page</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/css/fontawesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="../css/proceed.css" rel="stylesheet">
        <link href="../css/error_message.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <form id="paymentsForm" action="../php/process_order_file.php" method="post" onsubmit="return isPaymentsBil()">
                <div class="row" >
                    <div class="col">
                        <h3 class="title">Biling Amount </h3>
                        <div class="inputBox">
                            <span>Full Name : <i style="color:red">*</i></span>
                            <input type="text" name="fullnames" id="fullnames" placeholder="Full name"/>
                            <span id="fullnames-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>Email : <i style="color:red">*</i></span>
                            <input type="email" name="email" id="email" placeholder="Email" />
                            <span id="email-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>Address : <i style="color:red">*</i></span>
                            <input type="text" name="address" id="address" placeholder="Address" />
                            <span id="address-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>City/Town : <i style="color:red">*</i></span>
                            <input type="text" name="city" id="city" placeholder="City" />
                            <span id="city-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>Suburb : <i style="color:red">*</i></span>
                            <input type="text" name="suburb" id="suburb" placeholder="Suburb" />
                            <span id="suburb-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>ZIP Code : <i style="color:red">*</i></span>
                            <input type="text" name="postCode" id="postCode" placeholder="1234" />
                            <span id="postCode-error" class="error-message"></span>
                        </div>
                    </div>

                    <div class="col">
                        <h3 class="title">Payment</h3>
                        <div class="inputBox">
                            <span>Card Accepted :</span>
                            <img src="../images/card_img.png">
                        </div>
                        <div class="inputBox">
                            <span>Name Of Card : <i style="color:red">*</i></span>
                            <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="card" name="card">
                                <option disabled="" selected="">--Please select bank--</option>
                                <option value="Standard Bank">Standard Bank</option>
                                <option value="FirstRand">FirstRand</option>
                                <option value="ABSA ">ABSA</option>
                                <option value="Nedbank">Nedbank</option>
                                <option value="Capitec">Capitec</option>
                            </select>
                            <span id="card-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>Credit Card Number : <i style="color:red">*</i></span>
                            <input type="text" name="cardNumber" id="cardNumber" placeholder="****************" />
                            <span id="cardNumber-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>Pay Amount :<b>R<?= $price ?></b></span>
                            <input type="text" name="amount" id="amount" placeholder="<?= $price ?>" />
                            <input type="hidden" name="price" id="price" value="<?= $price ?>"/>
                            <span id="amount-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>Expiry Date: <i style="color:red">*</i></span>
                            <input type="text" id="expiry" name="expiry" placeholder="MM/YY" >
                            <span id="expiry-error" class="error-message"></span>
                        </div>

                        <div class="inputBox">
                            <span>3-Digit <b>CVV</b> Numbers: <i style="color:red">*</i></span>
                            <input type="text" id="cvv" name="cvv" placeholder="***" >
                            <span id="cvv-error" class="error-message"></span>
                        </div>
                    </div>
                </div>

                <input type="submit" value="Proceed to checkout" class="submit-btn">
            </form>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="../javascript/payments.js"></script>
    </body>
</html>