<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="image/x-icon" href="../images/logo.jpg">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/error_message.css">
    <title>Reset Password</title>
</head>
<body>
    <div class="container">
        <div class="form">
            <span class="title">Reset Password</span></br>
            <form  id="resetPasswordForm" action="../php/check_email_file.php" method="post" onsubmit="return isEmailAddress()">
                <p class="text">
                    Enter your email address to generate a OTP Code to reset password.
                </p>
                <div class="field">
                    <input type="email" name="email" id="email" placeholder="Enter your email"/>
                    <i class='bx bxs-envelope'></i>
                </div>
                <span id="email-error" class="error-message" ></span>

                <div class="field button">
                    <input type="submit" value="Reset Password">
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
     integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
     crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="../javascript/reset_password.js"></script>
</body>
</html>