<?php

include '../database_config/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    //checking email into database
    $checkEmailQuery = "SELECT * FROM person "
            . "WHERE email = '$email' ";

    $emailCheckedResult = $conn->query($checkEmailQuery);

    if ($emailCheckedResult->num_rows == 1) {
        echo "<script>alert('❌ Email already exists. Try to login');window.location.href = '../php/register.php';</script>";
        exit(); // Stop further execution
    }

    //declare the defeat image location
    $location = '../profile_images/download.png';

    //insert data into database 
    $insertSQL = "INSERT INTO `person` (`firstname`, `lastname`, `email`, `phone`, `password`, `location`) 
        VALUES (?, ?, ?, ?, ? ,?)";

    $stmt = $conn->prepare($insertSQL);

    // Check if statement preparation was successful
    $stmt->bind_param("ssssss", $firstName, $lastName, $email, $phone, $password, $location);

    if ($stmt->execute()) {
        $mail = new PHPMailer(true);

        try {
            // Set mailer to use SMTP
            $mail->isSMTP();

            // Specify main and backup SMTP servers
            $mail->Host = 'smtp.gmail.com';

            // Enable SMTP authentication
            $mail->SMTPAuth = true;

            // SMTP username
            $mail->Username = 'bryannevhutalu7@gmail.com';

            // SMTP password
            $mail->Password = 'giczlilkdytwrkuc';

            // Enable TLS encryption, `ssl` also accepted
            $mail->SMTPSecure = 'ssl';

            // TCP port to connect to
            $mail->Port = 465;

            //Recipients
            $mail->setFrom('bryannevhutalu7@gmail.com', 'Nova Associate Account');

            // Add a recipient
            $mail->addAddress($email);

            // Optional: Add reply-to address
            $mail->addReplyTo($email, 'Information');

            // Content
            $mail->isHTML(true);
            // Set email format to HTML
            $mail->Subject = 'Nova Associate Account';
            $mail->Body = "Hi <b>".$firstName." "."$lastName</b><br><br>"
                    . "</b>🎉 Welcome to <b>Nova Associate</b> — your account has been created successfully!<br>You can now login and purchase your house plan.<br><br>"
                    . "Thanks<br>"
                    . "The <b>Nova Associate</b> Team ";
            $mail->AltBody = '';

            $mail->send();
            echo "<script>alert('✅ Customer registered successfully.');window.location.href='../php/login.php';</script>";
            exit(); // Stop further execution
        } catch (Exception $e) {
            echo "<script>alert('❌ Email is not sent. Mailer Error: {$mail->ErrorInfo} ');</script>";
            exit();
        }
    } else {
        echo "<script>alert('❌ Something went wrong try again.');window.location.href='../php/register.php';</script>";
        exit(); // Stop further execution
    }

    // Close connection
    $stmt->close();
    $conn->close();
}
  
