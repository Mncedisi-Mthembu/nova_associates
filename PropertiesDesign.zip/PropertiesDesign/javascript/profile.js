$(document).ready(function () {
    $('#profileForm').submit(function (event) {
        event.preventDefault(); // Prevent default form submission

        if (isValidateProfile()) {
            this.submit(); // Proceed with submission if validation passes
        }
    });
});

function isValidateProfile() {
    let firstName = $('#firstName').val();
    let lastName = $('#lastName').val();
    let email = $('#email').val();
    let phone = $('#phone').val();
    let password = $('#password').val();
    let image = $('#image').val();

    // Reset previous error messages
    $('#firstName-error').hide();
    $('#lastName-error').hide();
    $('#email-error').hide();
    $('#phone-error').hide();  
    $('#password-error').hide();
    $('#image-error').hide();

    let isValid = true;
    
    //Validate image
    if(!image){
        $('#image-error').text('❌ Image is required.').show();
        isValid = false;
    }
    
    //Validate phone number
    if(!phone){
        $('#phone-error').text('❌ Phone number is required.').show();
        isValid = false;
    }else if (!/^0[6-8][0-9]{8}$/.test(phone)){
        $('#phone-error').text('❌ Invalid phone number. Number format[0123456789]').show();
        isValid = false;
    }

    //Validate last name
    if(!lastName){
        $('#lastName-error').text('❌ Last name is required.').show();
        isValid = false;
    }else if (!/^[A-Za-z ]+$/.test(lastName)) {
        $('#lastName-error').text('❌ Invalid last name, Name must have only letters.').show();
        isValid = false;
    }
    
    //Validate first name
    if(!firstName){
        $('#firstName-error').text('❌ First name is required.').show();
        isValid = false;
    }else if (!/^[A-Za-z ]+$/.test(firstName)) {
        $('#firstName-error').text('❌ Invalid first name, Name must have only letters.').show();
        isValid = false;
    }
    
    // Validate email
    if (!email) {
        $('#email-error').text('❌ Email is required.').show();
        isValid = false;
    }

    // Validate password
    if (!password) {
        $('#password-error').text('❌ Password is required.').show();
        isValid = false;
    } else if (!isStrongPassword(password)) {
        $('#password-error').text('❌ Password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.').show();
        isValid = false;
    }
    
    return isValid;
};

// Function to check if the password is strong
function isStrongPassword(password) {
    const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return strongPasswordRegex.test(password);
}
;

