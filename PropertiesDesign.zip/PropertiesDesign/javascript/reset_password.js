$(document).ready(function () {
    $('#resetPasswordForm').submit(function (event) {
        event.preventDefault(); // Prevent default form submission

        if (isEmailAddress()) {
            this.submit(); // Proceed with submission if validation passes
        }
    });
});

function isEmailAddress() {
    let email = $('#email').val();
    $('#email-error').hide();

    let isValid = true;

    // Validate email
    if (!email) {
        $('#email-error').text('❌ Email is required.').show();
        isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        $('#email-error').text('❌ Invalid email address.').show();
        isValid = false;
    }

    return isValid;

}