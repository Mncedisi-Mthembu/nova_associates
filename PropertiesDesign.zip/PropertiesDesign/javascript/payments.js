$(document).ready(function () {
    $('#paymentsForm').submit(function (event) {
        event.preventDefault(); // Prevent default form submission

        if (isPaymentsBil()) {
            this.submit(); // Proceed with submission if validation passes
        }
    });
});

function isPaymentsBil() {
    let fullnames = $('#fullnames').val();
    let email = $('#email').val();
    let address = $('#address').val();
    let city = $('#city').val();
    let suburb = $('#suburb').val();
    let postCode = $('#postCode').val();

    let card = $('#card').val();
    let cardNumber = $('#cardNumber').val();
    let amount = $('#amount').val();
    let price = $('#price').val();
    let expiry = $('#expiry').val();
    let cvv = $('#cvv').val();

    // Reset previous error messages
    $('#fullnames-error').hide();
    $('#email-error').hide();
    $('#address-error').hide();
    $('#city-error').hide();
    $('#suburb-error').hide();
    $('#postCode-error').hide();

    $('#card-error').hide();
    $('#cardNumber-error').hide();
    $('#amount-error').hide();
    $('#price-error').hide();
    $('#expiry-error').hide();
    $('#cvv-error').hide();

    let isValid = true;

    //Validate cvv
    if (!cvv) {
        $('#cvv-error').text("❌ CVV numbers is required").show();
        isValid = false;
    } else if (!/^\d{3}$/.test(cvv)) {
        $('#cvv-error').text("❌ Invalid CVV digit. CVV must be 3 digit").show();
        isValid = false;
    }

    //Validate expiry
    if (!expiry) {
        $('#expiry-error').text("❌ Expiry is required").show();
        isValid = false;
    } else if (!isValidExpiryDate(expiry)) {
        $('#expiry-error').text("❌ Invalid or expired MM/YY date.").show();
        isValid = false;
    }

    //Validate amount 
    if (!amount) {
        $('#amount-error').text("❌ Amount is required").show();
        isValid = false;
    } else if (amount < price) {
        $('#amount-error').text("❌ R" + amount + " is not enough").show();
        isValid = false;
    } else if (!/^\d+$/.test(amount)) {
        $('#amount-error').text("❌ Amount must be digit only").show();
        isValid = false;
    }

    //Validate card number
    if (!cardNumber) {
        $('#cardNumber-error').text("❌ Credit card number is required").show();
        isValid = false;
    } else if (!isValidCardNumber(cardNumber)) {
        $('#cardNumber-error').text("❌ Invalid Credit card number").show();
        isValid = false;
    } else if (!/^\d{16}$/.test(cardNumber)) {
        $('#cardNumber-error').text("❌ Credit card number must have only 16 digit").show();
        isValid = false;
    }

    //Card selection
    if (!card) {
        $('#card-error').text("❌ Bank is required").show();
        isValid = false;
    }
    //Validate Post code
    if (!postCode) {
        $('#postCode-error').text("❌ ZIP code is required").show();
        isValid = false;
    } else if (!/^\d{4}$/.test(postCode)) {
        $('#postCode-error').text("❌ Post code must be only 4 digit format[0000].").show();
        isValid = false;
    }

    //Validate suburb
    if (!suburb) {
        $('#suburb-error').text("❌ Suburb is required").show();
        isValid = false;
    }

    //Validate city
    if (!city) {
        $('#city-error').text("❌ City/Town is required").show();
        isValid = false;
    } else if (!/^[A-Za-z]+$/.test(city)) {
        $('#city-error').text("❌ Invalid name of the city/town").show();
        isValid = false;
    }

    //Validate address
    if (!address) {
        $('#address-error').text("❌ Address is required").show();
        isValid = false;
    }

    //Validate email address
    if (!email) {
        $('#email-error').text("❌ Email is required").show();
        isValid = false;
    }

    //Validate full names
    if (!fullnames) {
        $('#fullnames-error').text("❌ Names are required").show();
        isValid = false;
    } else if (!/^[A-Za-z\s]+$/.test(fullnames)) {
        $('#fullnames-error').text("❌ Only letters and spaces allowed.").show();
        isValid = false;
    }
    return isValid;
}
;


function isValidCardNumber(cardNumber) {

    // Must be all digits
    if (!/^\d+$/.test(cardNumber)) {
        return false;
    }

    let sum = 0;
    let shouldDouble = false;

    // Loop from right to left
    for (let i = cardNumber.length - 1; i >= 0; i--) {
        let digit = parseInt(cardNumber.charAt(i), 10);

        if (shouldDouble) {
            digit *= 2;
            if (digit > 9) {
                digit -= 9;
            }
        }

        sum += digit;
        shouldDouble = !shouldDouble;
    }

    return sum % 10 === 0;
}

function isValidExpiryDate(expiry) {
    // Match MM/YY format
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
        return false; // Invalid format
    }

    const [monthStr, yearStr] = expiry.split('/');
    const month = parseInt(monthStr, 10);
    const year = parseInt(yearStr, 10);

    // Check valid month
    if (month < 1 || month > 12) {
        return false;
    }

    // Get current month and year
    const today = new Date();
    const currentMonth = today.getMonth() + 1; // JS months start from 0
    const currentYear = today.getFullYear() % 100; // Get last 2 digits of year

    // Card should not be expired
    if (year < currentYear || (year === currentYear && month < currentMonth)) {
        return false;
    }

    return true;
}




