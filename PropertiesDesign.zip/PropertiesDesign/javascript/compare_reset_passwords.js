$(document).ready(function () {
    $('#resetPasswordForm').submit(function (event) {
        event.preventDefault(); // Prevent default form submission

        if (isCheckPassword()) {
            this.submit(); // Proceed with submission if validation passes
        }
    });
});

function isCheckPassword() {
    let password = $('#password').val();
    let confirm_password = $('#confirm_password').val();

    // Reset previous error messages
    $('#password-error').hide();
    $('#confirm_password-error').hide();


    let isValid = true;
    
    // Validate password
    if (!password) {
        $('#password-error').text('❌ Password is required.').show();
        isValid = false;
    } else if (!isStrongPassword(password)) {
        $('#password-error').text('❌ Password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.').show();
        isValid = false;
    }
    
    // Validate confirm password
    if (!confirm_password) {
        $('#confirm_password-error').text('❌ Verify password is required.').show();
        isValid = false;
    } else if (!isStrongPassword(confirm_password)) {
        $('#confirm_password-error').text('❌ Verify password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.').show();
        isValid = false;
    }
    
    //compare passwords
    if (confirm_password != password){
        $('#confirm_password-error').text('❌ Password not matched.').show();
        isValid = false;
    }

    return isValid;
}
;

// Function to check if the password is strong
function isStrongPassword(password) {
    const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return strongPasswordRegex.test(password);
}
;

