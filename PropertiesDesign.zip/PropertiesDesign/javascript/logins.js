$(document).ready(function () {
    $('#loginForm').submit(function (event) {
        event.preventDefault(); // Prevent default form submission

        if (isValidateLogin()) {
            this.submit(); // Proceed with submission if validation passes
        }
    });
});

function isValidateLogin() {
        let email = $('#email').val();
        let password = $('#password').val();

        // Reset previous error messages
        $('#email-error').hide();
        $('#password-error').hide();
   

        let isValid = true;

        // Validate email
        if (!email) {
            $('#email-error').text('❌ Email is required.').show();
            isValid = false;
        }

        // Validate password
        if (!password) {
            $('#password-error').text('❌ Password is required.').show();
            isValid = false;
        } else if (!isStrongPassword(password)) {
            $('#password-error').text('❌ Password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.').show();
            isValid = false;
        }

    return isValid;
    };

    // Function to check if the password is strong
    function isStrongPassword(password) {
        const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return strongPasswordRegex.test(password);
    };

